<footer class="site-footer">
    <div class="site-footer-legal">© 2019 E-Receipt</div>
   
  </footer>